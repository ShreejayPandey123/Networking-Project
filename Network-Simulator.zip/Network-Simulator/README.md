# Network Data Transmission Simulation Project

## Network Topology and Simulation Screenshots

Here are some screenshots showcasing different aspects of the simulation:

| ![Main Window](images/main.png) | ![Packet Delivery](images/topology.png) | ![Congestion Stats](images/congestion_stats.png) | ![Nodes Statistics](images/delivery_stats.png) |
| ------------------------------- | --------------------------------------- | ------------------------------------------------ | ---------------------------------------------- |
| Main Window                     | Network Topology                        | Congestion Statistics                            | Packet Delivery Statistics                     |

| ![Best Path](images/best_path.png) | ![Nodes Histogram](images/node_statistics.png) | ![Delay Histogram](images/delay_histogram.png) | ![Simulation Log](images/simulation_log.png) |
| ---------------------------------- | ---------------------------------------------- | ---------------------------------------------- | -------------------------------------------- |
| Best Path Calculation              | Nodes Statistics                               | Delay Histogram                                | Simulation Log                               |

## Overview

This project simulates a computer network that models the transmission of data packets across nodes with realistic network conditions such as congestion, packet loss, and varying link speeds. The simulation helps analyze network performance and behavior under different scenarios.

## Features

- **Network Topology Simulation:** The network is modeled as a graph where nodes represent devices and edges represent links with specified speeds.
- **Packet Transmission:** Data packets are sent through the network along paths determined by shortest path algorithms.
- **Dynamic Congestion Modeling:** The simulation incorporates congestion delays that affect the effective speed of links, simulating real-world network bottlenecks.
- **Packet Loss Simulation:** The model includes random packet drops to reflect unreliable network conditions.
- **Performance Metrics:** Calculates total transmission time, delivery rates, speeds, and congestion events.
- **Visualization:** Uses graphical interfaces to display the network topology, delivery statistics (histograms and pie charts), and best path calculations.
- **Interactive GUI:** Built with Tkinter for user input and real-time simulation control.

## How It Works

- The network graph stores link speeds between nodes.
- Packets are generated and routed through the network with delays based on link speeds and congestion.
- Packet loss and delays are randomly applied to simulate real network behavior.
- Total transmission time is calculated considering packet size, adjusted speeds due to congestion and network cost.
- Statistics and visualizations help users understand network performance and identify bottlenecks.

## Use Cases

- Educational tool for understanding network dynamics.
- Testing network algorithms under variable conditions.
- Analyzing the impact of congestion and packet loss on data transmission.

## Installation

Make sure you have Python 3.x installed along with the following packages:

```bash
pip install simpy networkx matplotlib
```
